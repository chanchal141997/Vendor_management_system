<?php include('./pages/db.php');
# create database connection

if(!empty($_POST["username"])) {
  $query = "SELECT * FROM admin WHERE username='" . $_POST["username"] . "'";
  $result = mysqli_query($connection,$query);
  $count = mysqli_num_rows($result);
  if($count>0) {
    echo "<span style='color:red'> Sorry User already exists .</span>";
    echo "<script>$('#submit').prop('disabled',true);</script>";
  }else{
    echo "<span style='color:green'> User available for Registration .</span>";
    echo "<script>$('#submit').prop('disabled',false);</script>";
  }
}


if(!empty($_POST["email"])) {
    $query = "SELECT * FROM admin WHERE email='" . $_POST["email"] . "'";
    $result = mysqli_query($connection,$query);
    $count = mysqli_num_rows($result);
    if($count>0) {
      echo "<span style='color:red'> Sorry Email Id already exists .</span>";
      echo "<script>$('#submit').prop('disabled',true);</script>";
    }else{
      echo "<span style='color:green'> Email available for Registration .</span>";
      echo "<script>$('#submit').prop('disabled',false);</script>";
    }
  }
?>