<?php
session_start(); ?>
<?php include './header.php'; ?>
<?php include './sidebar.php'; ?>
<?php include './db.php'; ?>
<?php
if (isset($_SESSION['email']) and ($_SESSION['vendor_id'])) {
    $email = $_SESSION['email'];


?>
    <?php
    if (isset($_POST['upload'])) {
        $vendor_id = $_SESSION['vendor_id'];
        $invoice_no = $_POST['invoice_no'];
        $invoice_date = date('Y-m-d H:i:s');
        $invoice_amt = $_POST['invoice_amt'];     
          $comment = $_POST['comment'];

        $invoice = $_FILES['invoice'];
        $po = $_FILES['po'];
        $signed_receipt = $_FILES['signed_receipt'];


        $filename = $invoice['name'];
        $filerrror = $invoice['error'];
        $filetmp = $invoice['tmp_name'];
        $fileext = explode('.', $filename);
        $filecheck = strtolower(end($fileext));
        $fileextstored = array('png', 'pdf', 'jpeg');

        $filename1 = $po['name'];
        $filerrror1 = $po['error'];
        $filetmp1 = $po['tmp_name'];
        $fileext1 = explode('.', $filename1);
        $filecheck1 = strtolower(end($fileext1));
        $fileextstored1 = array('png', 'pdf', 'jpeg');
    
        $filename2 = $signed_receipt['name'];
        $filerrror2 = $signed_receipt['error'];
        $filetmp2 = $signed_receipt['tmp_name'];
        $fileext2 = explode('.', $filename1);
        $filecheck2 = strtolower(end($fileext1));
        $fileextstored2 = array('png', 'pdf', 'jpeg');
            
        if (in_array($filecheck, $fileextstored)) {
            $destinationfile = '../invoice/' . $filename;
            $destinationfile1 = '../invoice/' . $filename1;
            $destinationfile2 = '../invoice/' . $filename2;

            move_uploaded_file($filetmp, $destinationfile);
            move_uploaded_file($filetmp1, $destinationfile1);
            move_uploaded_file($filetmp2, $destinationfile2);

        $query = "INSERT INTO `invoice_details`(`vendor_id`, `invoice_no`, `invoice_date`, `invoice_amt`, `invoice`, `po`, `signed_receipt`, `comment`) VALUES ('$vendor_id','$invoice_no','$invoice_date','$invoice_amt','$destinationfile','$destinationfile1','$ $destinationfile2','$comment')";
        $sql = mysqli_query($connection, $query);
        if ($sql) {
            echo '<script> alert("Invoice Details Uploaded successfully.....")</script>';
        }else{
            echo '<script> alert("Not Uploaded.....")</script>';
        }
    }}
    ?>

    <div class="main-wrapper">
        <div class=" w-100 d-flex no-block justify-content-center align-items-center  ">

            <div class="container-fluid" style="width: 60vw; align-items:center; margin-top:50px">

                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form class="form-horizontal" enctype='multipart/form-data' action='#' method='post'>
                                <div class="card-body">
                                    <h4 class="card-title"> Upload New Invoice </h4>
                                    <div class="form-group row">
                                        <label for="fname" class="col-sm-4 text-end control-label col-form-label">Invoice No <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="fname" name="invoice_no" placeholder="Enter Invoice No" required />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Date of Invoice <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="date" class="form-control" disabled id="lname" name="invoice_date" />
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Invoice Amount <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="lname" name="invoice_amt" placeholder="Enter Invoice Amt" required/>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Attach Invoice <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="file" class="form-control" id="lname" name="invoice" required/>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Attach PO/WO/Email Order<span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="file" class="form-control" id="lname" name="po" required/>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Attach Signed Delivery Receipt <span class="text-danger">*</span></label>
                                        <div class="col-sm-8">
                                            <input type="file" class="form-control" id="lname" name="signed_receipt" required/>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="lname" class="col-sm-4 text-end control-label col-form-label">Comments</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="lname" name="comment" maxlength="200"/>
                                        </div>
                                    </div>

                                </div>
                                <div class="border-top">
                                    <div class="card-body">
                                        <input type="submit" name="upload" class="btn btn-info" value="Upload">

                                        <a href="vendor_profile.php" class="btn btn-danger" value="Cancel">Cancel</a>

                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>

                </div>
            </div>
        </div>

    </div>


<?php } ?>













<?php include 'footer.php'; ?>