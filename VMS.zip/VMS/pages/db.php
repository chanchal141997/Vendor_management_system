<?php

// $db_host="sg2nlmysql57plsk.secureserver.net:3306";
// $db_user="meridian_dashboard";
// $db_pass="meridian@2022";
// $db_name="meridian_dashboard";

$db_host="localhost";
$db_user="root";
$db_pass="";
$db_name="VMS";
//sg2nlmysql57plsk.secureserver.net:3306 (default for Percona, v5.7.26)

$connection= mysqli_connect($db_host,$db_user,$db_pass,$db_name);

if($connection){
 //  echo "we are connected";
}

?>